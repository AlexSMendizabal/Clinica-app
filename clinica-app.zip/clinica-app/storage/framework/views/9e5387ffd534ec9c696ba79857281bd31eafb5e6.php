<div class="table-responsive">
    <!-- Projects table -->
    <table class="table align-items-center table-flush">
      <thead class="thead-light">
        <tr>
          <th scope="col">Descripción</th>
          <th scope="col">Especialidad</th>
            <?php if($role == 'patient'): ?>
                <th scope="col">Medico</th>
            <?php elseif($role == 'doctor'): ?>
                <th scope="col">Paciente</th>
            <?php endif; ?>
          <th scope="col">Fecha</th>
          <th scope="col">Hora</th>
          <th scope="col">Tipo</th>
        
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>


          <?php $__currentLoopData = $confirmedAppointment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <th scope="row">
                <?php echo e($appointment->description); ?>

              </th>
              <td>
                  <?php echo e($appointment->specialty->name); ?>

              </td>
                <?php if($role == 'patient'): ?>
                    <td>
                        <?php echo e($appointment->doctor->name); ?>

                    </td>
                <?php elseif($role == 'doctor'): ?>
                    <td>
                        <?php echo e($appointment->patient->name); ?>

                    </td>
                <?php endif; ?>

              <td>
                  <?php echo e($appointment->scheduled_date); ?>

                </td>
                <td>
                  <?php echo e($appointment->scheduled_time_12); ?>

                </td>
                <td>
                  <?php echo e($appointment->type); ?>

                </td>
             
                <td>
                    <a class="btn btn-sm btn-danger" title="Cancelar Cita" href="<?php echo e(route('citas.showcancel', $appointment->id)); ?>" >Cancelar cita</a>
                </td>
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <div class="card-body">
    <?php echo e($confirmedAppointment->links()); ?>

</div>
<?php /**PATH C:\xampp2\htdocs\clinica-app\resources\views/citas/citas_confirmadas.blade.php ENDPATH**/ ?>