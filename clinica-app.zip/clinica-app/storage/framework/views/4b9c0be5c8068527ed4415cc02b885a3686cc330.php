<?php $__env->startSection('content'); ?>

<div class="card shadow">
    <div class="card-header border-0">
      <div class="row align-items-center">
        <div class="col">
          <h3 class="mb-0">Nueva Especialidad</h3>
        </div>
        <div class="col text-right">
          <a href="<?php echo e(route('especialidades.index')); ?>" class="btn btn-sm btn-default ">Cancelar y Volver</a>
        </div>
      </div>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>

            <div class="alert alert-danger" role="alert">
                <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

         <?php endif; ?>

        <form action="<?php echo e(route('especialidades.store')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Nombre de la Especialidad</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
            </div>

            <div class="form-group">
                <label for="description">Descripción</label>
                <input type="text" name="descripcion" class="form-control" value="<?php echo e(old('description')); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\clinica-app\resources\views/especialidad/create.blade.php ENDPATH**/ ?>