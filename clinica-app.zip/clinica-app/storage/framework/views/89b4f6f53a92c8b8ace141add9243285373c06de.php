<?php $__env->startSection('content'); ?>

<div class="card shadow">
    <div class="card-header border-0">
      <div class="row align-items-center">
        <div class="col">
          <h3 class="mb-0">Nueva Paciente</h3>
        </div>
        <div class="col text-right">
          <a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-sm btn-default ">Cancelar y Volver</a>
        </div>
      </div>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger" role="alert">
                <?php $__currentLoopData = $errors->all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($error); ?>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php endif; ?>

        <form action="<?php echo e(route('pacientes.store')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Nombre del Paciente</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
            </div>

            <div class="form-group">
                <label for="ci">C.I.</label>
                <input type="ci" name="ci" class="form-control" value="<?php echo e(old('ci')); ?>">
            </div>
            <div class="form-group">
                <label for="email">Correo</label>
                <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <label for="address">Dirección</label>
                <input type="text" name="address" class="form-control" value="<?php echo e(old('address')); ?>">
            </div>
            <div class="form-group">
                <label for="phone">Celualr</label>
                <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="text" name="password" class="form-control" value="<?php echo e(Str::random(8)); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\clinica-app\resources\views/pacientes/create.blade.php ENDPATH**/ ?>