<footer class="footer">
  <div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
      <div class="copyright text-center text-xl-left text-muted">
        &copy; 2024 <a href="#" class="font-weight-bold ml-1" target="_blank"><?php echo e(config('app.name')); ?> Utepsa</a>
      </div>
    </div>
    <div class="col-xl-6">
     
    </div>
  </div>
</footer>
<?php /**PATH C:\xampp2\htdocs\clinica-app\resources\views/includes/panel/footer.blade.php ENDPATH**/ ?>